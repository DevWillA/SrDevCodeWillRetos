package com.willdev.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.willdev.model.Book;
import com.willdev.model.User;
import com.willdev.model.Loan;
import com.willdev.exception.NoSuchElementException;
import com.willdev.exception.UserNotFoundException;

import java.util.Optional;
import java.util.Scanner;

public class LibraryServiceTest {

    @InjectMocks
    private LibraryService libraryService;

    @Mock
    private BookService bookService;

    @Mock
    private UserService userService;

    @Mock
    private LoanService loanService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegisterBook() {
      
    }

    @Test
    void testRegisterUser() {
       
    }

    @Test
    void testMakeLoan() {
       
    }
}
