package com.willdev.exception;

public class NoSuchElementException extends RuntimeException  {

    public NoSuchElementException(String message)  {
        super(message);
    }

}
